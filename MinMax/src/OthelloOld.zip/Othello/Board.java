package Othello;

public class Board {
	public Cell [][] cells = new Cell [Othello.ROWS] [Othello.COLS]; 
	
	Board()
	{
		for (int i = 0; i < Othello.ROWS; i++) {
			for (int j = 0; j < Othello.COLS; j++) {
				cells[i][j] = new Cell( Seed.EMPTY );
			}
		}
	}
	Board ( Board other)
	{
		for (int i = 0; i < Othello.ROWS; i++) {
			for (int j = 0; j < Othello.COLS; j++) {
				cells[i][j] = new Cell( other.cells[i][j].content );
			}
		}

	}
	@Override
	public String toString()
	{
		StringBuffer str = new StringBuffer(100); 
		str.append( "   0   1   2   3   4   5   6   7 \n");
		str.append( " +---+---+---+---+---+---+---+---+\n");
		for (int i = 0; i < Othello.ROWS; i++) {
			str.append(i).append(": ");
			for (int j = 0; j < Othello.COLS; j++) {
				str.append(cells[i][j].toString());
				if ( j !=  Othello.COLS-1) str.append( " | ");			
			}
			str.append( " |\n");		
//			if ( i ==  Othello.ROWS-1)	
//				str.append( "\n");
//			else 
				str.append( " +---+---+---+---+---+---+---+---+\n");
		}
		return str.toString();
	}
	public void setMove(int[] move, Seed s)
	{
		AIPlayerMinimax othelloPlayer = new AIPlayerMinimax( this );
		othelloPlayer.setMove(move[0], move[1], s);
//		cells[move[0]][move[1]].content = s;
	}
	
	public Board clone()
	{
		return new Board (this);
	}
		
}
