package Othello;
/* ----------------------------------------------------------------------------------------------------------------------
minimax(level, player)  // player may be "computer" or "opponent"
if (gameover || level == 0)
   return score
children = all legal moves for this player
if (player is computer, i.e., maximizing player)
   // find max
   bestScore = -inf
   for each child
      score = minimax(level - 1, opponent)
      if (score > bestScore) bestScore = score
   return bestScore
else (player is opponent, i.e., minimizing player)
   // find min
   bestScore = +inf
   for each child
      score = minimax(level - 1, computer)
      if (score < bestScore) bestScore = score
   return bestScore

// Initial Call
minimax(2, computer)
--------------------------------------------------------------------------------------------------------------------- */


import java.util.*;
/** AIPlayer using Minimax algorithm */
public class AIPlayerMinimax extends AIPlayer {
	Board myBorad;

	/** Constructor with the given game board */
	public AIPlayerMinimax(Board board) {
		super(board);
		myBorad = board;
	}

	/** Get next best move for computer. Return int[2] of {row, col} */
	@Override
	int[] move() {
		int[] result = minimax(2, mySeed); // depth, max turn
		return new int[] {result[1], result[2]};   // row, col
	}

	/** Recursive minimax at level of depth for either maximizing or minimizing player.
       Return int[3] of {score, row, col}  */
	private int[] minimax(int depth, Seed player) {
		// Generate possible next moves in a List of int[2] of {row, col}.
		List<int[]> nextMoves = generateMoves( player );

		// mySeed is maximizing; while oppSeed is minimizing
		int bestScore = (player == mySeed) ? Integer.MIN_VALUE : Integer.MAX_VALUE;
		int currentScore;
		int bestRow = -1;
		int bestCol = -1;

		if (nextMoves.isEmpty() || depth == 0) {
			// Gameover or depth reached, evaluate score
			bestScore = evaluate();
		} else {
			for (int[] move : nextMoves) {
				Board keepBoard = myBorad.clone();
				// Try this move for the current "player"
				setMove( move[0], move[1], player );
				if (player == mySeed) {  // mySeed (computer) is maximizing player
					currentScore = minimax(depth - 1, oppSeed)[0];
					if (currentScore > bestScore) {
						bestScore = currentScore;
						bestRow = move[0];
						bestCol = move[1];
					}
				} else {  // oppSeed is minimizing player
					currentScore = minimax(depth - 1, mySeed)[0];
					if (currentScore < bestScore) {
						bestScore = currentScore;
						bestRow = move[0];
						bestCol = move[1];
					}
				}
				// Undo move
				myBorad.cells = keepBoard.cells;
				cells = keepBoard.cells;
			}
		}
		return new int[] {bestScore, bestRow, bestCol};
	}

	public void setMove(int row, int col, Seed seed)
	{
		// Sets in all direction
		checkAndReverseDirection(row, col, -1, -1, Math.min(row,col),               seed);
		checkAndReverseDirection(row, col, -1,  0, row,                             seed);
		checkAndReverseDirection(row, col, -1 , 1, Math.min(row,COLS-col-1),        seed);
		checkAndReverseDirection(row, col,  0, -1, col,                             seed);
		checkAndReverseDirection(row, col,  0,  1, COLS-col-1,                      seed);
		checkAndReverseDirection(row, col,  1 ,-1, Math.min(ROWS-row-1,col),        seed);
		checkAndReverseDirection(row, col,  1,  0, ROWS-row-1,                      seed);
		checkAndReverseDirection(row, col,  1,  1, Math.min(ROWS-row-1,COLS-col-1), seed);
		cells[row][col].content = seed;
	}

	private void checkAndReverseDirection(int row, int col, int rDir, int cDir, int stepsToBorder, Seed seed) {
		int revNum = getNumberOfSeedsToReverse( row, col, rDir, cDir,stepsToBorder, seed, theOtherSeed(seed) );
		if ( revNum >0 ) {
			reverse( row, col, rDir, cDir, revNum, seed );	// reverse (set to seed) appropriate cells
		}
	}

	/** Find all valid next moves.
       Return List of moves in int[2] of {row, col} or empty list if gameover */
	private List<int[]> generateMoves( Seed seed) {
		List<int[]> nextMoves = new ArrayList<int[]>(); // allocate List

		// Search for empty cells and add to the List
		for (int row = 0; row < ROWS; ++row) {
			for (int col = 0; col < COLS; ++col) {
				if ( isAvailable(row, col, seed) ) {
					nextMoves.add(new int[] {row, col});
				}
			}
		}
		return nextMoves;
	}

	/**
	 * 
	 * @param row
	 * @param col
	 * @param seed 
	 * @return
	 */
	private boolean isAvailable(int row, int col, Seed seed) {
		boolean isAv = true;

		// If cell not empty - return flase.
		if ( cells[row][col].content != Seed.EMPTY )
			return false;
		// Check in all directions whether or not cell is optional move
		isAv =              checkDirection( row, col, -1,-1, Math.min(row,col),               seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col, -1, 0, row,                             seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col, -1, 1, Math.min(row,COLS-col-1),        seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col,  0,-1, col,                             seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col,  0, 1, COLS-col-1,                      seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col,  1,-1, Math.min(ROWS-row-1,col),        seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col,  1, 0, ROWS-row-1,                      seed, theOtherSeed(seed) );
		if ( !isAv ) isAv = checkDirection( row, col,  1, 1, Math.min(ROWS-row-1,COLS-col-1), seed, theOtherSeed(seed) );
		return isAv;
	}

	private Seed theOtherSeed(Seed seed) {
		return seed==Seed.CROSS ? Seed.NOUGHT : Seed.CROSS;
	}

	private boolean checkDirection(int row, int col, int rDir, int cDir, int steps, Seed seed, Seed opSeed)
	{
		return  getNumberOfSeedsToReverse(row, col, rDir, cDir, steps, seed, opSeed) != 0;
	}

	/**
	 * Check if can set a specified cell (row,col) to seed. 
	 * The condition is that all cells in specified direction contains opseed (at least 1) and immediately followed by cell with seed.
	 * @param row: the specified cell row
	 * @param col: the specified cell column
	 * @param rDir: row direction. possible values: -1 -up, 0 - no change, 1-down (increasing)
	 * @param cDir: column direction. possible values: -1 -left, 0 - no change, 1-right (increasing)
	 * @param steps: maximum number of step in the specified direction until getting to board border
	 * @param seed: the seed we want to put in cell
	 * @param opSeed: the other seed
	 * @return	number of opseeds that can be reveres in specified direction.
	 */
	private int getNumberOfSeedsToReverse(int row, int col, int rDir, int cDir, int steps, Seed seed, Seed opSeed)
	{
		int revers = 0;
		if ( steps < 2 ) {
			return 0;
		}
		boolean findNoneOpSeed = false;
		int nrow = -1;
		int ncol = -1;

		// search for cell(s) with opponent seed in the specified direction. 
		// Exit the loop when find none opSeed or get to the border of the board.
		for (int i = 1; i <= steps && !findNoneOpSeed; i++) {
			nrow = row + i*rDir;
			ncol = col + i*cDir;
			if( cells[nrow][ncol].content == opSeed ) {
				revers += 1;
			}
			else {
				findNoneOpSeed = true;
			}
		}
		if ( findNoneOpSeed && revers>0 && cells[nrow][ncol].content == seed)
			return revers;
		return 0;		
	}

	/**
	 * Reverse (set to seed) a cells in one line from a specified cell.
	 * @param row: the row of the specified cell.
	 * @param col: the column of the specified cell.
	 * @param rDir: the direction of the rows
	 * @param cDir: the direction of the columns
	 * @param revNum: number of cells to set
	 * @param seed: the seed value to set
	 */
	private void reverse(int row, int col, int rDir, int cDir, int revNum, Seed seed)
	{
		for (int i = 1; i <= revNum; i++) {
			cells[row + i*rDir][col + i*cDir].content = seed;
		}
	}


	/** The heuristic evaluation function for the current board
       @Return +100, +10, +1 for EACH 3-, 2-, 1-in-a-line for computer.
               -100, -10, -1 for EACH 3-, 2-, 1-in-a-line for opponent.
               0 otherwise   */
	private int evaluate() {
		int mseeds = 0;
		int opseeds = 0;
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < COLS; j++) {
				if (cells[i][j].content == mySeed ) {
					mseeds += 1;
				} else if (cells[i][j].content == oppSeed ) {
					opseeds += 1;
				}
			}
		}
		return mseeds-opseeds;
	}

	/** The heuristic evaluation function for the given line of 3 cells
       @Return +100, +10, +1 for 3-, 2-, 1-in-a-line for computer.
               -100, -10, -1 for 3-, 2-, 1-in-a-line for opponent.
               0 otherwise */


	public boolean isGameOver() {
		if ( generateMoves( Seed.CROSS).isEmpty() && generateMoves( Seed.NOUGHT).isEmpty() ) 
			return true;
		return false;
	}
}